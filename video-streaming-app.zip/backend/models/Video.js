const mongoose = require("mongoose");

const VideoSchema = new mongoose.Schema({
    title: String,
    url: String,
    privacy: String,
    views: { type: Number, default: 0 },
    userId: mongoose.Schema.Types.ObjectId
});

module.exports = mongoose.model("Video", VideoSchema);
