require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const multer = require("multer");
const jwt = require("jwt-simple");
const bcrypt = require("bcryptjs");
const cors = require("cors");
const User = require("./models/User");
const Video = require("./models/Video");

const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const storage = multer.diskStorage({
    destination: "./uploads/",
    filename: (req, file, cb) => cb(null, Date.now() + "_" + file.originalname)
});
const upload = multer({ storage });

app.post("/register", async (req, res) => {
    const { username, email, password } = req.body;
    const hash = await bcrypt.hash(password, 10);
    const user = new User({ username, email, password: hash });
    await user.save();
    res.json({ message: "User registered!" });
});

app.post("/login", async (req, res) => {
    const user = await User.findOne({ email: req.body.email });
    if (user && bcrypt.compareSync(req.body.password, user.password)) {
        const token = jwt.encode({ id: user._id }, process.env.JWT_SECRET);
        res.json({ token });
    } else {
        res.status(401).json({ error: "Invalid credentials" });
    }
});

app.post("/upload", upload.single("video"), async (req, res) => {
    const { title, privacy, userId } = req.body;
    const video = new Video({ title, url: `/uploads/${req.file.filename}`, privacy, userId });
    await video.save();
    res.json({ message: "Video uploaded successfully!" });
});

app.get("/videos", async (req, res) => {
    const videos = await Video.find({ privacy: "public" });
    res.json(videos);
});

app.put("/video/:id/view", async (req, res) => {
    const video = await Video.findById(req.params.id);
    if (video) {
        video.views += 1;
        await video.save();
        res.json({ message: "View counted!" });
    } else {
        res.status(404).json({ error: "Video not found" });
    }
});

app.listen(5000, () => console.log("Server running on port 5000"));
