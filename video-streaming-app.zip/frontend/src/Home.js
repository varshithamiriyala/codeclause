import React, { useEffect, useState } from "react";
import axios from "axios";

const Home = () => {
    const [videos, setVideos] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:5000/videos").then(res => setVideos(res.data));
    }, []);

    return (
        <div>
            <h2>🎬 Public Videos</h2>
            {videos.map(video => (
                <div key={video._id}>
                    <h3>{video.title}</h3>
                    <video width="400" controls>
                        <source src={`http://localhost:5000${video.url}`} type="video/mp4" />
                    </video>
                    <p>👀 {video.views} views</p>
                </div>
            ))}
        </div>
    );
};

export default Home;
